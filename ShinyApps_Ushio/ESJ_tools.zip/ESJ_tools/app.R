####
#### 編成データから大会プログラムの作成
#### 2021.12.16 潮 作成
#### 2022.12.17 潮 更新
#### 2022.12.18 潮 Shiny アプリ化
#### 2022.12.20 潮 fix bugs
####


# ----------------------------------------------------- #
# パッケージの読み込み
# ----------------------------------------------------- #
library(shiny); packageVersion("shiny") # 1.7.2

library(tidyverse); packageVersion("tidyverse") # 1.3.2
library(lubridate); packageVersion("lubridate") # 1.8.0
library(stringr); packageVersion("stringr") # 1.4.1
library(hms); packageVersion("hms") # 1.1.2
library(readxl); packageVersion("readxl") # 1.4.1
library(cowplot); packageVersion("cowplot") # 1.1.1
#library(grDevices); packageVersion("grDevices") # 4.2.1
#library(showtext); packageVersion("showtext") # 0.9.5
theme_set(theme_cowplot())

## Loading Google fonts (https://fonts.google.com/)
#font_add_google("Noto Sans Japanese")
#font_install(source_han_serif())
# setHook(packageEvent("grDevices", "onLoad"), function(...) {
#   grDevices::pdf.options(family="Japan1GothicBBB"); ## ゴシック体
# });


# Prepare template
template_data <- read_excel("data/esj_oral_sample_data.xlsx")
#template_data <- read.csv("data/esj_oral_sample_data.csv")

# Define UI for application that draws a histogram
ui <- fluidPage(
  # タイトル
  titlePanel(h1(strong("ESJ 口頭発表タイムテーブル作成支援 with Shiny App")),
             windowTitle = "ESJ 口頭発表タイムテーブル作成支援"),
  # Author  
  fluidRow(column(12, p(HTML("2022-12-18 v1 Masayuki Ushio"),
                        style = "font-size:14px; color:gray;"))),
  # 説明
  fluidRow(column(12, p(HTML("発表編成データのうち、口頭発表のデータから大会プログラム用の口頭発表タイムテーブルを作成します。<br>
                             (1) 発表編成データが用意し、<br>
                             (2) 口頭発表のデータのみを抜き出してデータシートのテンプレートを埋めて、<br>
                             (3) データシートをシステムにアップロードして、<br>
                             (4) ｢タイムテーブルの作成｣ボタンを押します。<br>
                             (5) 作成したタイムテーブルの PDF ファイルと CSV ファイルをダウンロードして後の作業にご使用ください。"),
                        style = "font-size:14px; color:gray;"))),
  fluidRow(column(12, HTML("<br/>"))),
  fluidRow(column(12, p(HTML("問題が生じたときは ong8181 (at) gmail.com まで連絡してください。"),
                        style = "font-size:14px; color:gray;"))),
  # 文字のスタイルを指定
  tags$style("h2 {color:royalblue; font-weight: bold;}"),
  tags$style("hr {border-bottom: 1px solid gray;}"),
  
  # Step 1
  fluidRow(column(12, hr())),
  fluidRow(column(12, h2("1. 口頭発表データをアップロード"))),
  fluidRow(column(12, p(HTML("まずは口頭発表データをアップロード。\nサンプルのデータシートをダウンロードして、セルのデータを新しいものに入れ替えてください。"),
                        style = "font-size:14px; color:gray;"))),
  fluidRow(
    # Download template
    column(12, downloadButton("download_template", "テンプレートをダウンロード")),
  ),
  
  fluidRow(column(12, HTML("<br/>"))),
  fluidRow(column(12, p(HTML("編集した口頭発表データをアップロードしてください。"), style = "font-size:14px; color:gray;"))),
  fluidRow(
    # Upload a data file
    column(12, fileInput("presentation_data", "口頭発表データのアップロード"))
  ),

  fluidRow(column(12, HTML("<br/>"))),
  fluidRow(
    # Show target sequences
    column(6, actionButton("show_data", "アップロードしたデータを一部確認")),
  ),
  fluidRow(column(12, HTML("<br/>"))),
  fluidRow(column(12, p(HTML("＊ 2 列目、発表の月日は最初の 10 文字のみが使用されます. \"yyyy-mm-dd\" や \"yyyy/mm/dd\" を使用してください. それ以降の文字は無視されます."), style = "font-size:14px; color:red;"))),
  fluidRow(column(12, p(HTML("＊ 4-7 列目、セッション時間･講演時間は時刻のみが使用され、月日は無視されます."), style = "font-size:14px; color:red;"))),
  fluidRow(column(12, HTML("<br/>"))),
  fluidRow(
    # Show target sequences
    column(12, tableOutput("data_to_be_analyzed")),
  ),
  
  # Step 2
  fluidRow(column(12, hr())),
  fluidRow(column(12, h2("2. 口頭発表の日付・セクション区切りを指定"))),
  fluidRow(
    # Input forward primer
    column(6, textInput("sec1_end", h3("セクション 1 の終了時刻"), value = "2023-03-17 12:00:00")),
    # Input reverse primer
    column(6, textInput("sec2_end", h3("セクション 2 の終了時刻"), value = "2023-03-17 18:00:00")),
  ),
  
  fluidRow(
    # Input forward primer
    column(6, textInput("sec3_end", h3("セクション 3 の終了時刻"), value = "2023-03-18 12:00:00")),
    # Input reverse primer
    column(6, textInput("sec4_end", h3("セクション 4 の終了時刻"), value = "no_session")),
  ),

  
  # Step 3
  fluidRow(column(12, hr())),
  fluidRow(column(12, h2("3. タイムテーブルのサイズを指定"))),
  fluidRow(column(12, p(HTML("タイムテーブルのサイズ（横幅･高さ）を指定してください。"), style = "font-size:14px; color:gray;"))),
  fluidRow(
    # Input PDF width
    column(6, numericInput("pdf_width", h3("タイムテーブルの横幅"), value = 24, min = 0, max = 40)),
    # Input PDF height
    column(6, numericInput("pdf_height", h3("タイムテーブルの高さ"), value = 14, min = 0, max = 40)),
  ),
  
  # Step 4
  fluidRow(column(12, hr())),
  fluidRow(column(12, h2("4. タイムテーブルの生成･結果のダウンロード"))),
  fluidRow(column(12, p(HTML("ボタンを押してタイムテーブルを作成してください。"), style = "font-size:14px; color:gray;"))),
  fluidRow(
    # Download target sequences
    column(6, actionButton("generate_timetable", "タイムテーブルの生成")),
  ),
  fluidRow(column(12, HTML("<br/>"))),
  fluidRow(column(12, verbatimTextOutput("show_message"))),
  fluidRow(column(12, HTML("<br/>"))),
  fluidRow(column(12, HTML("<br/>"))),
  fluidRow(column(12, p(HTML("生成したタイムテーブルをダウンロードしましょう。"), style = "font-size:14px; color:gray;"))),
  fluidRow(
    # Download results
    column(6, downloadButton('result_download', "タイムテーブルをダウンロード"))
  ),
  fluidRow(column(12, HTML("<br/>"))),
  fluidRow(column(12, HTML("<br/>")))
)

# Define server logic required to draw a histogram
server <- function(input, output) {
  values <- reactiveValues(data_to_be_analyzed = NULL,
                           timetable_generated = NULL)

  output$download_template <- downloadHandler(
    filename = function() "template_data.csv",
    content = function(file) readr::write_excel_csv(template_data, file)
  )
  
  d0 <- eventReactive(input$presentation_data, {
    pres_d <- readr::read_csv(input$presentation_data$datapath)
    pres_d
  })
  
  # Show sequences to be analyzed
  observeEvent(input$show_data, {
    data_shown <- d0()[1:3, 1:5]
    values$data_to_be_analyzed <- data_shown
  })
  output$data_to_be_analyzed <- renderTable(values$data_to_be_analyzed)
  
  # Parameter check
  # pred_d$`編】講演番号.lecture_no`
  # input$sec1_end
  # input$sec2_end
  # input$sec3_end
  # input$sec4_end
  # 
  # input$pdf_width
  # input$pdf_height
  
  # タイムテーブルの生成スタート
  output$show_message <- eventReactive(input$generate_timetable, {
    # 時間測定
    start_time <- proc.time()[3]
    # 出力ファイルフォルダを準備
    if (dir.exists("output")) system("rm -r output")
    system("mkdir output")
    # Set parameters
    # 出力ファイル名
    output_csv_jp <- "JP_ESJ_Program.csv"
    output_csv_en <- "EN_ESJ_Program.csv"
    output_pdf_jp1 <- "JP_ESJ_Program_Sec1.pdf"
    output_pdf_en1 <- "EN_ESJ_Program_Sec1.pdf"
    output_pdf_jp2 <- "JP_ESJ_Program_Sec2.pdf"
    output_pdf_en2 <- "EN_ESJ_Program_Sec2.pdf"
    output_pdf_jp3 <- "JP_ESJ_Program_Sec3.pdf"
    output_pdf_en3 <- "EN_ESJ_Program_Sec3.pdf"
    output_pdf_jp4 <- "JP_ESJ_Program_Sec4.pdf"
    output_pdf_en4 <- "EN_ESJ_Program_Sec4.pdf"
    
    # Replace object
    d <- d0()
    #d <- readr::read_csv("data/esj_oral_sample_data.csv")
    #d <- readr::read_csv("~/Downloads/template_data.csv")
    # Start processing
    d_date <- d[,2] # 開催日時
    d_time <- d[,4:7] %>% # セッション時刻
      mutate(session_start = as_hms(as_datetime(`編】セッション開始時間.lecture_session_time_start`)),
             session_end = as_hms(as_datetime(`編】セッション終了時間.lecture_session_time_end`)),
             lecture_start = as_hms(as_datetime(`編】講演開始時間.lecture_time_start`)),
             lecture_end = as_hms(as_datetime(`編】講演終了時間.lecture_time_end`)))
    ## 日時の入れ替え
    d$`編】開催日.lecture_date` <- d_date$`編】開催日.lecture_date` %>%
      stringr::str_sub(end = 10) %>% lubridate::as_date()
    d$`編】セッション開始時間.lecture_session_time_start` <- d_time$session_start
    d$`編】セッション終了時間.lecture_session_time_end` <- d_time$session_end
    d$`編】講演開始時間.lecture_time_start` <- d_time$lecture_start
    d$`編】講演終了時間.lecture_time_end` <- d_time$lecture_end
    # 開催日時・場所の列を作成、改名
    d$lecture_date <- d$`編】開催日.lecture_date`
    d$lecture_date_time <- paste0(d$`編】開催日.lecture_date`, " ", d$`編】講演開始時間.lecture_time_start`)
    d$lecture_room <- d$`編】会場.lecture_room`
    # 口頭発表抽出
    #d_oral <- d %>% filter(`編】発表形式.presentation_type` == "口頭発表")
    d_oral <- d
    
    # 発表数を確認
    # dim(d_oral) # 241件
    # sum(is.na(d_oral$lecture_date_time)) # 全てに時間が割り当てられている? --> OK
    # sum(is.na(d_oral$lecture_room))      # 全てに部屋が割り当てられている? --> OK
    
    # ----------------------------------------------------- #
    # 口頭発表のリストを作成
    # ----------------------------------------------------- #
    # 第一著者のミドルネームのチェック
    #d_oral$author_middle_first_check_jp <- d_oral$`連名01_氏名(漢字-名+ミドル)` == d_oral$`連名01_氏名(漢字-名)`
    #d_oral$author_middle_first_check_en <- d_oral$`連名01_氏名(英字-名+ミドル)` == d_oral$`連名01_氏名(英字-名)`
    # 第一著者の情報追加
    d_oral$first_author_name_jp <- paste(d_oral$`連名01_氏名(漢字-姓)`, d_oral$`連名01_氏名(漢字-名+ミドル)`)
    d_oral$first_author_name_en <- paste(d_oral$`連名01_氏名(英字-名+ミドル)`, d_oral$`連名01_氏名(英字-姓)`)
    jp_en_same_name <- paste(d_oral$`連名01_氏名(漢字-名+ミドル)`, d_oral$`連名01_氏名(漢字-姓)`) == d_oral$first_author_name_en
    d_oral$first_author_name_jp[jp_en_same_name] <- paste(d_oral$`連名01_氏名(漢字-名+ミドル)`, d_oral$`連名01_氏名(漢字-姓)`)[jp_en_same_name]
    #d_oral$first_author_name_en[!jp_en_same_name] 
    d_oral$first_author_affiliation_jp <- paste0("(", d_oral$`連名01_所属(和名)`, ")")
    d_oral$first_author_affiliation_en <- paste0("(", d_oral$`連名01_所属(英名)`, ")")
    d_oral$first_author_info_jp <- paste(d_oral$first_author_name_jp, d_oral$first_author_affiliation_jp)
    d_oral$first_author_info_en <- paste(d_oral$first_author_name_en,d_oral$first_author_affiliation_en)
    
    # 部屋数
    #n_days <- length(unique(d_oral$lecture_date))
    #n_room <- length(unique(d_oral$lecture_room))
    #n_slot <- length(unique(d_oral$lecture_date_time))
    d_oral$lecture_date_time2 <- str_sub(d_oral$lecture_date_time, end = 16)
    
    # 日にち・午前午後を追加
    # Convert date time
    # sec1_end <- as_datetime("2023-03-17 12:00:00")
    # sec2_end <- as_datetime("2023-03-17 18:00:00")
    # sec3_end <- as_datetime("2023-03-18 12:00:00")
    # sec4_end <- "no_session"
    sec1_end <- as_datetime(input$sec1_end)
    sec2_end <- as_datetime(input$sec2_end)
    sec3_end <- as_datetime(input$sec3_end)
    if (input$sec4_end == "no_session") {
      sec4_end <- NA
    } else {
      sec4_end <- as_datetime(input$sec4_end)
    }

    # Assign slot
    id_sec1 <- ymd_hms(d_oral$lecture_date_time) < ymd_hms(sec1_end)
    id_sec2 <- ymd_hms(d_oral$lecture_date_time) > ymd_hms(sec1_end) & ymd_hms(d_oral$lecture_date_time) < ymd_hms(sec2_end)
    id_sec3 <- ymd_hms(d_oral$lecture_date_time) > ymd_hms(sec2_end) & ymd_hms(d_oral$lecture_date_time) < ymd_hms(sec3_end)
    if (!(is.na(sec4_end))) {
      id_sec4 <- ymd_hms(d_oral$lecture_date_time) > ymd_hms(sec3_end) & ymd_hms(d_oral$lecture_date_time) < ymd_hms(sec4_end)
    } else {
      id_sec4 <- ymd_hms(d_oral$lecture_date_time) > ymd_hms(sec3_end)
    }
    # Check duplicates
    id_df <- data.frame(id_sec1 = id_sec1,
                        id_sec2 = id_sec2,
                        id_sec3 = id_sec3,
                        id_sec4 = id_sec4)
    #rowSums(id_df)
    
    d_oral$lecture_slot1 <- NA
    d_oral$lecture_slot1[id_sec1] <- "Section_1"
    d_oral$lecture_slot1[id_sec2] <- "Section_2"
    d_oral$lecture_slot1[id_sec3] <- "Section_3"
    d_oral$lecture_slot1[id_sec4] <- "Section_4"
      
    # Check slot
    # dim(d_oral)
    # (n_sec1 <- sum(id_sec1))
    # (n_sec2 <- sum(id_sec2))
    # (n_sec3 <- sum(id_sec3))
    # (n_sec4 <- sum(id_sec4))
    # (n_sec1 + n_sec2 + n_sec3 + n_sec4)
    
    # ----------------------------------------------------- #
    # CSV ファイルとして書き出し
    # ----------------------------------------------------- #
    # Prepare frame
    cat_date <- unique(d_oral$lecture_date)
    cat_room <- unique(d_oral$lecture_room)
    cat_slot <- unique(d_oral$lecture_date_time2)
    csv_frame_jp <- matrix("", nrow = length(cat_slot), ncol = length(cat_room))
    csv_frame_en <- matrix("", nrow = length(cat_slot), ncol = length(cat_room))
    colnames(csv_frame_jp) <- colnames(csv_frame_en) <- cat_room
    rownames(csv_frame_jp) <- rownames(csv_frame_en) <- cat_slot
    
    # Assign presentation
    for (i in cat_slot) {
      for (j in cat_room) {
        slot_id <- (d_oral$lecture_date_time2 == i & d_oral$lecture_room == j)
        csv_frame_jp[i,j] <- paste0(d_oral$`編】講演番号.lecture_no`[slot_id], "\n", d_oral$`タイトル(和文)`[slot_id], "\n", d_oral$first_author_info_jp[slot_id])
        csv_frame_en[i,j] <- paste0(d_oral$`編】講演番号.lecture_no`[slot_id], "\n", d_oral$`タイトル(英文)`[slot_id], "\n", d_oral$first_author_info_en[slot_id])
      }
    }
    
    csv_frame_jp[csv_frame_jp == "\n"] <- ""
    csv_frame_en[csv_frame_en == "\n"] <- ""
    
    # Save as CSV file
    csv_frame_jp2 <- data.frame(cbind(cat_slot, csv_frame_jp))
    colnames(csv_frame_jp2)[1] <- "Date Time"
    csv_frame_en2 <- data.frame(cbind(cat_slot, csv_frame_en))
    colnames(csv_frame_en2)[1] <- "Date Time"
    #write.csv(csv_frame_jp, sprintf("%s/JP_ESJ69_Program.csv", output_folder), row.names = T, fileEncoding = "Shift-JIS")
    readr::write_excel_csv(csv_frame_jp2, sprintf("output/%s", output_csv_jp))
    readr::write_excel_csv(csv_frame_en2, sprintf("output/%s", output_csv_en))
    
    
    # ----------------------------------------------------- #
    # プログラムへの変換関数
    # ----------------------------------------------------- #
    ## Japanese version
    make_esj_program_jp <- function(original_data, section_name, program_title) {
      program_gg <- original_data %>%
        filter(lecture_slot1 == section_name) %>%
        ggplot(aes(x = 1, y = 1)) +
        geom_text(aes(x = 1, y = 1, label = stringr::str_wrap(first_author_info_jp, 35)),
                  family = "Japan1", size = 2.5, fontface = "bold") +
        geom_text(aes(x = 1, y = 11, label = stringr::str_wrap(`タイトル(和文)`, 40)),
                  family = "Japan1", size = 2.2) +
        facet_grid(lecture_date_time2 ~ lecture_room, switch = "y") +
        panel_border() +
        theme(axis.ticks = element_blank(),
              axis.text = element_blank(),
              strip.text.y.left = element_text(angle = 0)) +
        xlab(NULL) + ylab(NULL) + ylim(-5,20) +
        # Set font for Japanese
        theme(text = element_text(family = "Japan1")) +
        ggtitle(program_title) +
        NULL
      return(program_gg)
    }
    ## English version
    make_esj_program_en <- function(original_data, section_name, program_title) {
      program_gg <- original_data %>%
        filter(lecture_slot1 == section_name) %>%
        ggplot(aes(x = 1, y = 1)) +
        geom_text(aes(x = 1, y = 1, label = stringr::str_wrap(first_author_info_en, 35)),
                  family = "Japan1", size = 2.5, fontface = "bold") +
        geom_text(aes(x = 1, y = 11, label = stringr::str_wrap(`タイトル(英文)`, 40)),
                  family = "Japan1", size = 2.2) +
        facet_grid(lecture_date_time2 ~ lecture_room, switch = "y") +
        panel_border() +
        theme(axis.ticks = element_blank(),
              axis.text = element_blank(),
              strip.text.y.left = element_text(angle = 0)) +
        xlab(NULL) + ylab(NULL) + ylim(-5,20) +
        # Set font for Japanese
        theme(text = element_text(family = "Japan1")) +
        ggtitle(program_title) +
        NULL
      return(program_gg)
    }
    
    
    # ----------------------------------------------------- #
    # PDf size
    # ----------------------------------------------------- #
    #pdf_width <- 24
    #pdf_height <- 14
    pdf_width <- as.integer(input$pdf_width)
    pdf_height <- as.integer(input$pdf_height)
    
    # ----------------------------------------------------- #
    # プログラム: セクション 1
    # ----------------------------------------------------- #
    jp_p1 <- make_esj_program_jp(d_oral, "Section_1", "セクション 1")
    en_p1 <- make_esj_program_en(d_oral, "Section_1", "Section 1")
    
    ## Save figure
    ggsave(file = sprintf("output/%s", output_pdf_jp1), plot = jp_p1,
           family = "Japan1", width = pdf_width, height = pdf_height)
    ggsave(file = sprintf("output/%s", output_pdf_en1), plot = en_p1,
           family = "Japan1", width = pdf_width, height = pdf_height)
    # ggsave(file = sprintf("output/%s", output_pdf_jp1), plot = jp_p1,
    #        device = cairo_pdf, width = pdf_width, height = pdf_height)
    # quartz(file = sprintf("output/%s", output_pdf_jp1),
    #        type = "pdf", family = "HiraKakuPro-W3", width = 24, height =14)
    # jp_p1; dev.off()
    # quartz(file = sprintf("output/%s", output_pdf_jp1),
    #        type = "pdf", family = "HiraKakuPro-W3", width = pdf_width, height = pdf_height)
    # jp_p1; dev.off()
    # quartz(file = sprintf("output/%s", output_pdf_en1),
    #        type = "pdf", family = "HiraKakuPro-W3", width = pdf_width, height = pdf_height)
    # en_p1; dev.off()
    
    
    # ----------------------------------------------------- #
    # プログラム: セクション 2
    # ----------------------------------------------------- #
    jp_p2 <- make_esj_program_jp(d_oral, "Section_2", "セクション 2")
    en_p2 <- make_esj_program_en(d_oral, "Section_2", "Section 2")
    
    ## Save figure
    ggsave(file = sprintf("output/%s", output_pdf_jp2), plot = jp_p2,
           family = "Japan1", width = pdf_width, height = pdf_height)
    ggsave(file = sprintf("output/%s", output_pdf_en2), plot = en_p2,
           family = "Japan1", width = pdf_width, height = pdf_height)
    # quartz(file = sprintf("output/%s", output_pdf_jp2),
    #        type = "pdf", family = "HiraKakuPro-W3", width = pdf_width, height = pdf_height)
    # jp_p2; dev.off()
    # quartz(file = sprintf("output/%s", output_pdf_en2),
    #        type = "pdf", family = "HiraKakuPro-W3", width = pdf_width, height = pdf_height)
    # en_p2; dev.off()
    
    
    # ----------------------------------------------------- #
    # プログラム: セクション 3
    # ----------------------------------------------------- #
    jp_p3 <- make_esj_program_jp(d_oral, "Section_3", "セクション 3")
    en_p3 <- make_esj_program_en(d_oral, "Section_3", "Section 3")
    
    ## Save figure
    ggsave(file = sprintf("output/%s", output_pdf_jp3), plot = jp_p3,
           family = "Japan1", width = pdf_width, height = pdf_height)
    ggsave(file = sprintf("output/%s", output_pdf_en3), plot = en_p3,
           family = "Japan1", width = pdf_width, height = pdf_height)
    # quartz(file = sprintf("output/%s", output_pdf_jp3),
    #        type = "pdf", family = "HiraKakuPro-W3", width = pdf_width, height = pdf_height)
    # jp_p3; dev.off()
    # quartz(file = sprintf("output/%s", output_pdf_en3),
    #        type = "pdf", family = "HiraKakuPro-W3", width = pdf_width, height = pdf_height)
    # en_p3; dev.off()
    
    
    # ----------------------------------------------------- #
    # プログラム: セクション 4
    # ----------------------------------------------------- #
    if (!(is.na(sec4_end))) {
      jp_p4 <- make_esj_program_jp(d_oral, "Section_4", "セクション 4")
      en_p4 <- make_esj_program_en(d_oral, "Section_4", "Section 4")

      ## Save figure
      ggsave(file = sprintf("output/%s", output_pdf_jp4), plot = jp_p4,
             family = "Japan1", width = pdf_width, height = pdf_height)
      ggsave(file = sprintf("output/%s", output_pdf_en4), plot = en_p4,
             family = "Japan1", width = pdf_width, height = pdf_height)
      # quartz(file = sprintf("output/%s", output_pdf_jp4),
      #        type = "pdf", family = "HiraKakuPro-W3", width = pdf_width, height = pdf_height)
      # jp_p4; dev.off()
      # quartz(file = sprintf("output/%s", output_pdf_en4),
      #        type = "pdf", family = "HiraKakuPro-W3", width = pdf_width, height = pdf_height)
      # en_p4; dev.off()
    }
    if(F){
    #######################
    # For Bug fix ------->
    } #####################
    
    #readr::write_excel_csv(d_oral, "output/d_tmp.csv")
    # 終了メッセージ
    time_elapsed <- proc.time()[3] - start_time
    sprintf("タイムテーブルの生成が終了しました!\n経過時間: %.02f 秒", time_elapsed)
  })
  
  output$result_download <- downloadHandler(
    filename = "ESJ_Timetable.zip",
    content = function(file){
      files <- NULL
      for(i in list.files("output/")) files <- paste(files, paste0("output/", i))
      #create the zip file
      system2("zip", args=(paste(file, files)))
    },
    contentType = "application/zip"
  )
}

# Run the application 
shinyApp(ui = ui, server = server)
